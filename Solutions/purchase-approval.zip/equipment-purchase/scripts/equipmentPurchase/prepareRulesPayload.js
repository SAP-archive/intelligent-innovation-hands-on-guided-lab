  /************ Define Vocabulary ******************/
  var Vocabulary = [{
  	"OrderDetails": {
		"EmployeeName": $.context.emp.name,
		"EmployeeRole": $.context.emp.role,
		"EmployeeRegion": $.context.emp.region,
		"ProductType": $.context.prod.category,
		"ProductCost": $.context.prod.cost
  	}
  }];
  
  var rulesPayload = {
  	"RuleServiceId": "6deb51363b9746e8bc10fdf5540593b8",
  	"Vocabulary": Vocabulary
  };
  
  $.context.rulesPayload = rulesPayload;
  
  /************ Enhance Workflow Context for additional attributes ****************/
  var attributes = {
  	"OrderDetails": {
		"EmployeeName": $.context.emp.name,
		"EmployeeRole": $.context.emp.role,
		"EmployeeRegion": $.context.emp.region,
		"ProductType": $.context.prod.category,
		"ProductCost": $.context.prod.cost
  	}
  };
  
  $.context.attributes = attributes;